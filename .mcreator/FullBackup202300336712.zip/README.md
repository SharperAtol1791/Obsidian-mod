# Obsidian-mod
This is a mod for minecraft 1.20.1 fabric that adds obsidian items
